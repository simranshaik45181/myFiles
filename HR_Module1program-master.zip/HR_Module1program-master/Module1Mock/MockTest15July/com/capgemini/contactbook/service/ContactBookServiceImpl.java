package com.capgemini.contactbook.service;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;

public class ContactBookServiceImpl implements ContactBookService{
	ContactBookDaoImpl cbd = new ContactBookDaoImpl();;

	public long addEnquiry(EnquiryBean bean) throws ContactBookException{
		//System.out.println("\n\nServices\n\n");
		long ck;
		ck = cbd.addEnquiry(bean);
		return ck;

	}	
	public EnquiryBean getEnquiryDetails(long enquiryId) throws ContactBookException{     
		if(cbd.getEnquiryDetails(enquiryId)==null) {
			return null;
		}
		else {
			return cbd.getEnquiryDetails(enquiryId);
		}
	}
	//validateContactNo
	// validateFirstName
	// validateLastName
	//  validatePLocation
	//  validatePDomain
	/*@Override
	public boolean isValidEnquiry(EnquiryBean bean) throws ContactBookException {
		long len1 = bean.getEnqryId();
		String len = Long.toString(len1);
		if(len.length()<8 || len.length()>13) {
			return false;
		}
		return true;
	}*/
	@Override
	public boolean checkNo(String contactNo) throws Exception {
		if(contactNo.length()!=10) {
			throw new Exception();
		}
		return true;
	}
	@Override
	public boolean checkName(String fName) throws Exception {
		char[] ch = fName.toCharArray();
		if(ch[0] <'A' || ch[0]>'Z' || fName.equalsIgnoreCase(null)) {
			throw new Exception();
		}
		return true;
	}
	@Override
	public boolean checkEmpty(String check) throws Exception {
		char ch[] = check.toCharArray();
		if(check.equalsIgnoreCase(null) && ch[0]<'a' && ch[0]>'z' && ch[0]<'A' && ch[0]>'Z' && ch[0]>'1' && ch[0] <'9') {
			throw new Exception();
		}
		return true;
	}

}
