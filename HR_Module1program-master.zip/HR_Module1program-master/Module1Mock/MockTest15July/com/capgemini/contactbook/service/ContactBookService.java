package com.capgemini.contactbook.service;

import com.capgemini.contactbook.bean.EnquiryBean;

public interface ContactBookService {
	public long addEnquiry(EnquiryBean  bean) throws ContactBookException;
	public EnquiryBean getEnquiryDetails(long enquiryId) throws ContactBookException;
	//public boolean isValidEnquiry(EnquiryBean bean) throws ContactBookException;
	boolean checkNo(String contactNo) throws Exception;
	boolean checkName(String fName) throws Exception;
	boolean checkEmpty(String check) throws Exception;
}
