package com.capgemini.contactbook.service;

public class ContactBookException extends Exception{
	
	public ContactBookException(String message){
		System.out.println(message);
	}
}
