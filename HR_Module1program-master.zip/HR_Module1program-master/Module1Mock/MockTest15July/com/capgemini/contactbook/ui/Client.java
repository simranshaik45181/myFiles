package com.capgemini.contactbook.ui;

import java.util.Random;
import java.util.Scanner;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.service.*;

public class Client{
	static EnquiryBean eb = new EnquiryBean(), eb1;
	static ContactBookServiceImpl cs = new ContactBookServiceImpl();
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) throws ContactBookException {
		// User Interface which display the operation menu to add an enquiry, search an enquiry.
				// Create object for service and execute the respective methods
				String n;
				while(true) {

					n = inputs();

					switch(n) {

					case "1":
						System.out.print("\nEnter First Name :\t\t");
						String fName;
						while(true) {
							fName = sc.next();
							try {	
								if(cs.checkName(fName) == false) {
									throw new Exception();
								}
								else {
									break;
								}
							}
							catch(Exception e) {
								System.out.println("First alphabet should be capital");
								System.out.print("\nEnter First Name :\t\t");
								continue;
							}
						}

						System.out.print("Enter Last Name :\t\t");
						String lName;
						while(true) {
							try {	
								lName = sc.next();
								if(cs.checkName(lName) == false) {
									throw new Exception();
								}

								else {
									break;
								}
							}
							catch(Exception e) {
								System.out.println("First alphabet should be capital");
								System.out.print("Enter Last Name :\t\t");
								continue;
							}
						}
						System.out.print("Enter Contact Number :\t\t");
						String contact;
						while(true) {
						try {
							contact = sc.next();
							if(cs.checkNo(contact) == false) {
								throw new Exception();
							}
							else {
								break;
							}
						}
						catch(Exception e) {
							System.out.println("\t\tNumber should be 10 digit numerics.\n");
							System.out.print("Enter Contact Number :\t\t");
							continue;
						}
						}
						long contactNo = Long.parseLong(contact);

						System.out.print("Enter Preferred Domain :\t");
						String pDomain;
						while(true) {
							try {
								pDomain = sc.next();
								if(cs.checkEmpty(pDomain) == false) {
									throw new Exception();
								}
								else {
									break;
								}
							}
							catch(Exception e) {
								System.out.println("\t\tDomain should not be Empty.\n");
								System.out.print("Enter Preferred Domain :\t");
								continue;
							}
						}	
						System.out.print("Enter Preferred Location :\t");
						String pLocation;
						while(true) {
						try {
							pLocation = sc.next();
							if(cs.checkEmpty(pLocation) == false) {
								throw new Exception();
							}
							else {
								break;
							}
						}
						catch(Exception e) {
							System.out.println("\t\tLocation should not be Empty.\n");
							System.out.print("Enter Preferred Location :\t");
							continue;
						}
						}
						Random d = new Random();
						long enqryId = d.nextInt();

						eb.setEnqryId(enqryId);
						eb.setfName(fName);
						eb.setlName(lName);
						eb.setContactNo(contactNo);
						eb.setpDomain(pDomain);
						eb.setpLocation(pLocation);
						//System.out.println(eb.getEnqryId() + "\t" +eb.getfName() + "\t" + eb.getlName() + "\t" 
						//		+ eb.getContactNo() + "\t" + eb.getpDomain() + "\t" + eb.getpLocation() );
						
						if(cs.addEnquiry(eb) == 1) {
							System.out.println("Thank you " + eb.getfName() + " " + eb.getlName() + " your Unique Id is " + eb.getEnqryId()  + " we will contact you shortly.");
						}
						else {
							System.out.println("\n\t\tNot Inserted");
						}
						break;

					case "2":
						System.out.print("\nEnter the Enquiry No :\t\t\t");
						long enquiryId = sc.nextLong();
						/*if(cs.isValidEnquiry(eb)==false) {
							System.out.println("Enter correct ID.");
							break;
						}*/
						
						eb1 = cs.getEnquiryDetails(enquiryId);
						if(eb1==null) {
							System.out.println("\n\t\t\tNot Found\n");
						}
						else {
							System.out.println("Id\t\t" + "First Name\t" + "Last Name\t" + "Contact No.\t" 
												+ "Preferred Domain\t" + "Preferred Location");
							System.out.println(eb.getEnqryId() + "\t" +eb.getfName() + "\t\t" + eb.getlName() + "\t" 
												+ eb.getContactNo() + "\t\t" + eb.getpDomain() + "\t" + eb.getpLocation() );
						}
						break;

					case "3":
						System.out.println("\n\n\t\t\tThank you selecting us!!");
						System.exit(0);

					}
				}
	}
	
	static String inputs() {
		System.out.println("*********************Global Recruitments*****************");
		System.out.println("\t\t\tChoose an operation :\n");
		System.out.println("\t\t\t1. Enter Enquiry Details");
		System.out.println("\t\t\t2. View Enquiry Details on Id");
		System.out.println("\t\t\t3. Exit");

		System.out.print("\t\t\tPlease enter a choice : \t");
		String n = sc.next();
		return n;
	}
}