package com.capgemini.contactbook.dao;

import java.util.*;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.service.ContactBookException;

public class ContactBookDaoImpl implements ContactBookDao {
	private Map<Long,EnquiryBean> enquiryEntry = new HashMap<Long, EnquiryBean>();
	EnquiryBean eb;

	@Override
	public long addEnquiry(EnquiryBean bean) throws ContactBookException {
		//System.out.println("\n\nDAO\n\n");
		long ck=1;
		long id = bean.getEnqryId();
		enquiryEntry.put(id, bean);
		if(enquiryEntry.containsKey(id)) {
			//System.out.println("\n IF contains : "+enquiryEntry.containsKey(id)+"\n");
			return ck;
		}
		else {
			ck=0;
			return ck;
		}
	}

	@Override
	public EnquiryBean getEnquiryDetails(long enquiryId) throws ContactBookException {
		if(enquiryEntry.containsKey(enquiryId)) {
			eb = (EnquiryBean) enquiryEntry.get(enquiryId);
			//System.out.println(eb.getEnqryId());
			return eb;
		}
		else {
			return null;
		}
	}
}
