package com.capgemini.takehome.bean;

public class Product {
	String productName, productCategory;
	int   productId, productPrice;
	
	public Product(int id, String name, String ProdDept, int price) {
		productId = id;
		productName = name;
		productCategory = ProdDept;
		productPrice = price;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
}
