package com.capgemini.takehome.ui;

import java.util.*;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.service.ProductService;

public class Client {
	static private ProductService ss;
	static Product p ;
	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);

			System.out.println("Enter Product Details : ");
			ss = new ProductService();

			while(true) {
				int id, quant;
				System.out.print("Enter the product code :\t\t");
				try {
					String code = sc.next();
					if(ss.validCode(code) == false) {
						throw new Exception();
					}
					else {
						id = Integer.parseInt(code);
					}
				}
				catch(Exception e) {
					System.out.println("\t\tEnter 4 digit Product Id and should be number");
					break;
				}


				System.out.print("Enter the quantity :\t\t\t");
				try {
					String quantity = sc.next();
					if(ss.validQuant(quantity) == false) {
						throw new Exception();
					}
					else {
						quant = Integer.parseInt(quantity);
					}
				}
				catch(Exception e) {
					System.out.println("\t\tQuantity should be greater than 4 and should be numbers");
					break;
				}

				p = ss.getProductDetails(id);
				if(p == null) {
					System.out.println("Sorry ! The Product Code " +  id + " is not available.");
					break;
				}
				else {
					System.out.println("\nCalculating Total and displaying the bill");

					System.out.println("\nProduct Name: \t\t"  + p.getProductName() +
							"\nProduct Category: \t" + p.getProductCategory() +
							"\nProduct Description: \t" + p.getProductCategory() +
							"\nProduct Price (Rs): \t" + p.getProductPrice() +
							"\nQuantity: \t\t" + quant +
							"\nLine Total (Rs): \t" + p.getProductPrice()*quant + 
							"");
					break;
				}

			}
	}
}
