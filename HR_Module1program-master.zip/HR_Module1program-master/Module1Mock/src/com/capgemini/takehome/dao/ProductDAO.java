package com.capgemini.takehome.dao;

import java.util.*;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.util.CollectionUtil;

public class ProductDAO implements IProductDAO{

	Product p;
	CollectionUtil cu = new CollectionUtil();
	
	@Override
	public Product getProductDetails(int productCode) {
		HashMap<Integer, Product> hm = (HashMap<Integer, Product>) cu.getDetails(productCode);
		if(hm.containsKey(productCode)) {
			p = (Product) hm.get(productCode);
		}
		else {
			p = null;
		}
		return p;
	}

}
