package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.ProductDAO;

public class ProductService implements IProductService {
	ProductDAO pd = new ProductDAO();
	
	public Product getProductDetails (int productCode) {
		
		return pd.getProductDetails(productCode);
	}
	
	
	
	@Override
	public boolean validCode(String code) {
		if(code.length() > 4 || code.length() <= 0) {
			return false;
		}
		else {
			return true;
		}
	}

	@Override
	public boolean validQuant(String quant) {
		if(quant.length() <= 0) {
			return false;
		}
		else {
			return true;
		}
	}

}
