package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;

public interface IProductService {
	boolean validCode(String code);
	boolean validQuant(String quant);
	
	Product getProductDetails (int productCode);
	 
	

}
