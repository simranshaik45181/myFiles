package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.cg.entities.Employee;

@Repository("employeeRepository")
public class EmployeeRepositoryImpl implements EmployeeRepository {

	//Below annotation is required to inject auto created entityManager from entityManagerFactory
	@PersistenceContext
	private EntityManager entityManager;

	/* (non-Javadoc)
	 * @see com.cg.dao.EmployeeRepository#save(com.cg.entities.Employee)
	 */
	
	@Override
	public Employee save(Employee employee) {

		entityManager.persist(employee);
		entityManager.flush();	//required to reflect changes on database
		
		return employee;
	}
	/* (non-Javadoc)
	 * @see com.cg.dao.EmployeeRepository#loadAll()
	 */
	@Override
	public List<Employee> loadAll() {
		TypedQuery<Employee> query = entityManager.createQuery("SELECT e FROM Employee e", Employee.class);
		return query.getResultList();
	}
	@Override
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Employee findEmployeeById(Long employeeid) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void deleteAllInBatch() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void deleteInBatch(Iterable<Employee> arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public List<Employee> findAll(Sort arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Employee> findAll(Iterable<Long> arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void flush() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Employee getOne(Long arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public <S extends Employee> List<S> save(Iterable<S> arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public <S extends Employee> S saveAndFlush(S arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Page<Employee> findAll(Pageable arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void delete(Long arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void delete(Employee arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void delete(Iterable<? extends Employee> arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean exists(Long arg0) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public Employee findOne(Long arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
