package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,Long> {

	public abstract Employee save(Employee employee);

	public abstract List<Employee> loadAll();

	public abstract Employee findEmployeeById(Long employeeid);
	
}