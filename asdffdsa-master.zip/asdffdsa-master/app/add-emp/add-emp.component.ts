import { Component, OnInit } from '@angular/core';
import { ServiceService, Employee } from '../service.service';

@Component({
  selector: 'app-add-emp',
  templateUrl: './add-emp.component.html',
  styleUrls: ['./add-emp.component.css']
})
export class AddEmpComponent implements OnInit {

  emp:Employee;
  service:ServiceService;

  constructor(service:ServiceService) {
    this.service=service;
  }

  ngOnInit() {
  }

  add(data:any) {
    this.emp = new Employee(data.id, data.name, data.title, data.gender, data.age);
    this.service.add(this.emp);
  }
}
