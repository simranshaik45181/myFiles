import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  http:HttpClient;
  emp:Employee[] = [];
  constructor(http:HttpClient) {
    this.http = http;
   }

   fetched:boolean = false;
   fetchData() {
     this.http.get('./assets/Employee.json').subscribe(
       data=>{
         if(!this.fetched){
           this.convert(data);
           this.fetched = true;
         }
       }
     )
   }

   convert(data :any) {
     for(let d of data) {
       let dd = new Employee(d.id, d.name, d.title, d.gender, d.age);
       this.emp.push(dd);
     }
   }

  add(emp:Employee){
    this.emp.push(emp);
    // console.log(this.emp);
  }

  getData(): Employee[] {
    // console.log(this.emp);
    return this.emp;
  }

  del(id) {
    let check:number = -1;
    for(let i=0; i<this.emp.length; i++) {
      if(id == this.emp[i].id) {
        check = i;
        break;
      }
    }
    this.emp.splice(check, 1);
  }
}

export class Employee {
  id:number;
  name:string; title:string; gender:string; age:string;
  constructor(id:number, name:string, title:string, gender:string, age:string) {
    this.age = age;
    this.id = id;
    this.name = name;
    this.title = title;
    this.gender = gender;
  }
}