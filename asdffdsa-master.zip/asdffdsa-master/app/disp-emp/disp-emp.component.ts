import { Component, OnInit } from '@angular/core';
import { ServiceService, Employee } from '../service.service';
import { splitClasses } from '@angular/compiler';

@Component({
  selector: 'app-disp-emp',
  templateUrl: './disp-emp.component.html',
  styleUrls: ['./disp-emp.component.css']
})
export class DispEmpComponent implements OnInit {

  service:ServiceService
  emp:Employee[] = [];

  constructor(service:ServiceService) {
    this.service = service
   }

  ngOnInit() {
    this.service.fetchData();
    this.emp = this.service.getData();
  }

  del(id) {
    this.service.del(id);
    this.service.fetchData();
  }

}
