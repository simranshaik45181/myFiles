import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEmpComponent } from './add-emp/add-emp.component';
import { DispEmpComponent } from './disp-emp/disp-emp.component';


const routes: Routes = [
  {
    path:'app-add-emp',
    component: AddEmpComponent
  },
  {
    path:'app-disp-emp',
    component: DispEmpComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
