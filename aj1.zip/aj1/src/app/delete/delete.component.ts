import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from '../product-service.service';
import { ShowProductsComponent } from '../show-products/show-products.component';
import { Product } from '../product';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
product:Product;
  
  constructor(private productService:ProductServiceService,private show: ShowProductsComponent) { }
  ngOnInit() {
  }


  deleteProduct(data):void{
   
  this.productService.deleteProduct(data.id).subscribe(data => {
  alert('Delete Successful');
  });
 }
}
