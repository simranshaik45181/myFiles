import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from "../product-service.service";
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router,private userService: ProductServiceService) { }

  ngOnInit() {
  }

  login(uName, pwd) {
    this.userService.login(uName, pwd).subscribe(data => {
      this.userService.setid(data);
      alert("link has been successfully sent to your registered mail" )
      this.router.navigate(['/homecomponent']);
    }, error => { alert("Wrong credentials") });
  };

}
