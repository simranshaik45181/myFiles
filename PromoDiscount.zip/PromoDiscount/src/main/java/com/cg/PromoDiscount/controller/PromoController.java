package com.cg.PromoDiscount.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.PromoDiscount.entity.Promo;
import com.cg.PromoDiscount.service.PromoService;

@RestController
public class PromoController {

	@Autowired
	PromoService promoService;

	@PostMapping("/addpromo")
	public Promo addPromo(@RequestBody Promo promo) {
		return promoService.addPromo(promo);
	}

	@GetMapping("/getPromos")
	 public List<Promo> getAllPromos(){
		 return promoService.getAllPromo();
	 }
	@GetMapping("/getpromo/{promoCode}")
	public Promo getPromo(@PathVariable String promoCode) {
		return promoService.getPromo(promoCode);
		
	}
	@GetMapping("/getDiscount/{promoId}")
	public int getDiscount(@PathVariable int promoId) {
		return promoService.getDiscount(promoId);
	}
}
/*
 * int getDiscount(int promoId); public void addPromo(Promos promo);
 * 
 * public List<Promos> getAllPromos();
 * 
 * public Promos getPromo(String promoCode);
 */