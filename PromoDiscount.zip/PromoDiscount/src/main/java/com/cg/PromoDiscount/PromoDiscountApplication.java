package com.cg.PromoDiscount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PromoDiscountApplication {

	public static void main(String[] args) {
		SpringApplication.run(PromoDiscountApplication.class, args);
	}

}
