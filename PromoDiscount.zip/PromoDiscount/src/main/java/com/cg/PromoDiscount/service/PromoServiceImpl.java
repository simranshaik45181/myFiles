package com.cg.PromoDiscount.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.cg.PromoDiscount.dao.PromoDao;
import com.cg.PromoDiscount.entity.Promo;

@Service
public class PromoServiceImpl implements PromoService {

	@Autowired
	PromoDao promoDao;

	@Override
	public Promo addPromo(Promo promo) {
		return promoDao.save(promo);
	}

	@Override
	public List<Promo> getAllPromo() {
		return promoDao.findAll();
	}

	@Override
	public Promo getPromo(String promoCode) {
		return promoDao.getPromoByPromoCode(promoCode);
	}

	@Override
	public int getDiscount(int promoId) {
	Promo p= (Promo) promoDao.findById(promoId).get();

		
	return p.getDiscount();
		//return promoDao.findById(promoId);

		
		
	}

}
