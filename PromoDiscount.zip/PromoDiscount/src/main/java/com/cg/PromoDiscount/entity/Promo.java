package com.cg.PromoDiscount.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Promo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int promoId;

	@Column
	private String promoCode;
	
	@Column
	private int discount;
	
	
	@Column
	@JsonFormat(pattern = "dd-MM-yyyy")
	private Date endDate;

	public Promo(int promoId, String promoCode, int discount, Date endDate) {
		super();
		this.promoId = promoId;
		this.promoCode = promoCode;
		this.discount = discount;
		this.endDate = endDate;
		
	}

	public Promo() {
		super();
	}

	public int getPromoId() {
		return promoId;
	}

	public void setPromoId(int promoId) {
		this.promoId = promoId;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "Promo [promoId=" + promoId + ", promoCode=" + promoCode + ", discount=" + discount + ", startDate="
				 + ", endDate=" + endDate + "]";
	}

}
/* private String promoImageUrl; */