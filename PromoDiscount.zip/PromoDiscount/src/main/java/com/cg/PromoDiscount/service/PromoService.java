package com.cg.PromoDiscount.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;


import com.cg.PromoDiscount.entity.Promo;

public interface PromoService {

	public Promo getPromo(String promoCode);

	public Promo addPromo(Promo promo);

	public List<Promo>  getAllPromo();

	public int getDiscount(int promoId);

}
