import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { HttpClient } from '@angular/common/http';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  httpClient: HttpClient;
  service: MyserviceService;
  customer: Customer[];
i;
  constructor(httpClient: HttpClient, service: MyserviceService) {
    this.service = service;
    this.httpClient=httpClient;
  }


  ngOnInit() {
    this.service.getCustomer().subscribe(data=>{
        // this.customer = new Customer(data.id, data.name,data.phone);
        
        //  this.customer[0] = new Customer(data[0].id, data[0].name, data[0].phone);
         console.log(data[0].id);

        // while(this.i < 2){
        //   this.customer[this.i] = new Customer(data[this.i].id, data[this.i].name, data[this.i].phone);
        //   this.i++;
        // }

      })
  }

  
}