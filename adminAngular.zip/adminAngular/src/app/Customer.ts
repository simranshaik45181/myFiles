export class Customer{

     id: number;
     name: String;
     phone: number;

     constructor(id: number, name:String, phone: number){
          this.phone = phone;
          this.id = id;
          this.name = name;
     }
    
}