import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServicService {

  http : HttpClient;
  service : ServicService;

  emp : Employee[] = [];
  
  constructor(http : HttpClient) {
    this.http = http;
   }

   fetch : boolean = false;

   fetchData(){
     this.http.get('./assets/Chitkara.json').subscribe(
       data =>{
         if(!this.fetch){
           this.convert(data);
           this.fetch = true;
         }
       }
     )
   }

   convert(data : any){
     for(let dd of data){
       let e = new Employee(dd.id, dd.name, dd.phone);
       this.emp.push(e);
     }
   }

   getData() : Employee[]{
     return this.emp;
   }

   add(fname, lname, phone, email, gender, password):Observable<any>{
    console.log(fname+ " " + lname + " " + phone + " " + email + " "+ gender+" " +password )
     let obj = {
      "fname": fname,
      "lname": lname,
      "mobileNo": phone,
      "emailId": email,
      "gender": gender,
      "password" : password
     }
     let url = "http://localhost:8093/create";
     return this.http.post(url, obj);
   }


   update(data : Employee){
     let eid = data.id;
     for(let i=0; i<this.emp.length; i++){
       if(eid == this.emp[i].id){
         this.emp[i].name = data.name;
         
         this.emp[i].phone = data.phone;
         break;
       }
     }
   }

employee1: Employee[] = [];

 search(data):Employee[] {
 this.employee1=[];
 for(let e of this.emp) {
 if(e.id==data.id) {
 this.employee1.push(e);
 }
 }
 return this.employee1;
 }
}

export class Employee{
  id : number;
  name : string;
  phone : number;
  constructor(id : number, name : string , phone : number){
      this.id = id;
      this.name = name;
      this.phone = phone;
  }
}