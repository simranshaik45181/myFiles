import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  emp: Employee = new Employee();

  constructor(private employeeService: EmployeeService) { }

  ngOnInit() {
  }

  insert(data) {
    alert('Employee Added');
    this.emp.name=data.name;
    this.emp.designation=data.designation;
    this.emp.salary=data.salary;
    this.employeeService.setEmployeeDetails(this.emp);
  }

}
