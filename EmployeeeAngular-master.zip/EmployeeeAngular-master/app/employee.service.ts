import { Injectable } from '@angular/core';
import { Employee } from './Employee';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employeeList: Array<Employee>=[];
  url: string ="/assets/employee.json";

  constructor(private httpClient:HttpClient) { 
    this.getEmployeeDetails().subscribe(data => this.employeeList = data);
  }

  getEmployeeDetails(): any {
    return this.httpClient.get<Employee>(this.url);
  }

  setEmployeeDetails(emp: Employee) {
     this.employeeList.push(emp);
  }
  
}
