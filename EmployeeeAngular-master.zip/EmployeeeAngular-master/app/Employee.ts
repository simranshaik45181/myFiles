export class Employee{

    name:string;
    designation:string;
    salary:number;

}