import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  emp: Employee = new Employee();

  employeeList: any=[];
  constructor(private employeeService:EmployeeService) { 
    this.employeeList=this.employeeService.employeeList;
  }

  ngOnInit() {
   // this.employeeList=this.employeeService.employeeList;
  }
  // reload() {
  //   this.employeeList=this.employeeService.employeeList;
  // }

}
