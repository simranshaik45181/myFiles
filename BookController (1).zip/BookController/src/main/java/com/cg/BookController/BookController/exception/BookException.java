package com.cg.BookController.BookController.exception;

public class BookException extends Exception{
	public BookException() {
		
	}
	public BookException(String msg ){
		super(msg);
	}
}
