package com.cg.BookController.BookController.Service;

import java.util.List;
import java.util.Optional;

import com.cg.BookController.BookController.Beans.Book;
import com.cg.BookController.BookController.exception.BookException;

public interface IBookService {
	public List<Book> getAllBooks() throws BookException;
	public List<Book> addBook(Book pro) throws BookException;
	public void deleteBook(int id) throws BookException;
	public List<Book> updateBook(int id, Book pro) throws BookException;
	public List<Book> findByPri(int price, int price1) throws BookException;
	public List<Book> greaterBy(int price) throws BookException;
	public List<Book> getByName(String name) throws BookException;
	public Book getById(int id) throws BookException;
}
