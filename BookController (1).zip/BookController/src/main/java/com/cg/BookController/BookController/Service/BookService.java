package com.cg.BookController.BookController.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.BookController.BookController.Beans.Book;
import com.cg.BookController.BookController.DAO.IBookDAO;
import com.cg.BookController.BookController.exception.BookException;

@Service
public class BookService implements IBookService {

	@Autowired
	IBookDAO bookDAO;

	@Override
	public List<Book> getAllBooks() throws BookException {
		// TODO Auto-generated method stub
		try {
			return bookDAO.findAll();
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public List<Book> addBook(Book pro) throws BookException {
		try {
			bookDAO.save(pro);

			return bookDAO.findAll();
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public void deleteBook(int id) throws BookException {
		try {
			bookDAO.deleteById(id);
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public List<Book> updateBook(int id, Book pro) throws BookException {
		try {
			Optional<Book> optional = bookDAO.findById(id);

			if (optional.isPresent()) {
				Book book = optional.get();
//            book.setId(pro.getId());
				book.setName(pro.getName());
				book.setPrice(pro.getPrice());
				book.setAuthor(pro.getAuthor());

				bookDAO.save(book);

				return bookDAO.findAll();
			} else {
				return null;
			}
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	public List<Book> findByPri(int price, int price1) throws BookException {
		try {
			return bookDAO.findByPri(price, price1);

		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public List<Book> greaterBy(int price) throws BookException {
		try {
			return bookDAO.findBygreater(price);

		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public List<Book> getByName(String name) throws BookException {
		try {
			return bookDAO.getByName(name);
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public Book getById(int id) throws BookException {
		try {

			return bookDAO.findById(id).get();
		} catch (Exception e) {
			throw new BookException("Product ID : " +id+ " not found");
		}
	}
}
