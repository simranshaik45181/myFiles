package com.cg.eis.dao;

import java.util.Collection;

import com.cg.eis.bean.Order;

public interface OrderRepo {
	
	public int saveOrder(Order bean);

       public Collection<Order> getAllOrders();
}
