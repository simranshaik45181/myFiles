package com.cg.eis.exception;

// When quantity is less than 1 then this exception is used
public class QuantityException extends Exception{
	
	public QuantityException() {
		System.out.println("Quantity should not be less than 1");
	}
	
}
