package com.cg.eis.ui;

import java.util.Scanner;

import com.cg.eis.bean.Order;
import com.cg.eis.dao.OrderRepoImpl;
import com.cg.eis.exception.QuantityException;
import com.cg.eis.service.OrderServiceImpl;
import com.cg.eis.service.Validator;

public class Client {
	
	/*
        Refer the sample input and output for the presentation layer messages
        Do not use tab or extra newline, which will lead to presentation error.
        Do not provide any additional messages, which is not asked for
    */

	public static void main(String[] args) {
		
		int ch, id, quantity;
		double price;
		
		Scanner sc = new Scanner(System.in);
		OrderServiceImpl order = new OrderServiceImpl();
		Validator validate = new Validator();
		Order bean;
		OrderRepoImpl dao = new OrderRepoImpl();
		
		// To take input from user and perform the operations as per the requirement
		//Refer sample input / output given in question description
		
		while(true) {
			System.out.println("1-Add New Order");
			System.out.println("2-Print All Orders");
			System.out.println("3-Exit");
			System.out.println("Enter your choice");
			ch = sc.nextInt();
			switch(ch) {
			case 1:
				bean = new Order();
				System.out.println("Enter the order id");
				id = sc.nextInt();
				bean.setId(id);
				do {
					System.out.println("Enter price of each Item (in Dollars)");
					price = sc.nextDouble();
					bean.setPrice(price);
				}while(validate.isPriceValid(price) != true);
				
				
//				do {
//					System.out.println("Enter the quantity");
//					quantity = sc.nextInt();
//				}
//				while(validate.isQuantityValid(quantity) != true);
				
				
				
				System.out.println("Enter the quantity");
				quantity = sc.nextInt();
				try {
					if(validate.isQuantityValid(quantity) == true) {
						bean.setQuantity(quantity);
						if(order.saveOrder(bean) == 0) {
							System.out.println("Order " +id+ " successfully added");
						}
					}
				} catch (QuantityException e) {
				}
				
				break;
			case 2:
				if(order.getAllOrders() == null) {
					System.out.println("No order found");
				}
				else {
					System.out.println("Id  Price(Dollar)  Quantity  Amount(INR)  Conversion charges");
					System.out.println(order.getAllOrders());
				}
				break;
			case 3:
				System.out.println("END");
				return;
			default:
				System.out.println("Invalid Choice");
			}
		}
	}
}