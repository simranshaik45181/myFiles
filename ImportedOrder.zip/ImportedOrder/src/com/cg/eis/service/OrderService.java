package com.cg.eis.service;

import java.util.Collection;

import com.cg.eis.bean.Order;

public interface OrderService {
	
	
	public int saveOrder(Order bean);

          public Collection<Order> getAllOrders();
}
