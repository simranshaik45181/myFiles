import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Transaction } from '../Transaction';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
serviceService:ServiceService;
transaction:Transaction;
trans1:Transaction;

  constructor(serviceService:ServiceService) {
    this.serviceService=serviceService;
   }

  fundTransfer(data:any){
    let transId = Math.floor(Math.random() * 100) + 10;
    let transId1 = Math.floor(Math.random() * 100) + 10;
    this.transaction = new Transaction(transId, "Transfer Money", data.transferbalance, data.sourceaccountNo);
    this.trans1 = new Transaction(transId1, "Recieve Money", data.transferbalance, data.destaccountNo);
    this.serviceService.fundTransfer(data, this.transaction, this.trans1);
    
  
  }
  ngOnInit() {
  }

}
