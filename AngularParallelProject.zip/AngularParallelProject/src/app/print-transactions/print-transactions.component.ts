import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Transaction } from '../Transaction';

@Component({
  selector: 'app-print-transactions',
  templateUrl: './print-transactions.component.html',
  styleUrls: ['./print-transactions.component.css']
})
export class PrintTransactionsComponent implements OnInit {
serviceService:ServiceService;
transaction:Transaction[]=[];
  constructor(serviceService:ServiceService) {
    this.serviceService=serviceService;
   }


  printTransaction(data:any){
    this.transaction = this.serviceService.printTransaction(data);
  }
  ngOnInit() {
  }

}
