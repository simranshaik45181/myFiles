import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Customer } from '../Customer';
import { Transaction } from '../Transaction';

@Component({
  selector: 'app-createaccount',
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.css']
})
export class CreateaccountComponent implements OnInit {

  serviceService: ServiceService;
customer:Customer;
transaction: Transaction;
  constructor(serviceService: ServiceService) { 
    this.serviceService=serviceService;
  }

  add(data:any){
    let accountNo =Math.floor(Math.random()*100)+1000;
    let transId = Math.floor(Math.random() * 100) + 10;
    console.log(accountNo);
    this.customer=new Customer(accountNo,data.bname, data.bmobile,data.badhaar,data.bbalance,data.bpin);
    this.transaction = new Transaction(transId, "Created Account", data.bbalance, accountNo);
this.serviceService.add(this.customer,this.transaction);
  }
  ngOnInit() {
  }

}
