import { Injectable } from '@angular/core';
import { Customer } from './Customer';
import { Transaction } from './Transaction';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
customer:Customer[]=[];
transaction: Transaction[] = [];

ShowCustomerDetails: Customer;
  constructor() { }

  add(customer:Customer,transaction:Transaction){
    this.customer.push(customer);
    alert("Your accountNumber is:"+customer.accountNo)
  }

  showDetails(data:any):Customer{
    for( let i=0;i<this.customer.length;i++){
      let Cust=this.customer[i];
      if (Cust.accountNo == data.accountNo) {
      if(Cust.pin == data.pin){
        this.ShowCustomerDetails =Cust;
        return this.ShowCustomerDetails;
        
      }
    }
  }
}
  depositDetails(data:any,transaction:Transaction){
    for (let i = 0; i < this.customer.length; i++) {
      let Cust = this.customer[i];
      if (Cust.accountNo == data.daccountNo) {
        if (Cust.pin == data.dpin) {
          Cust.balance = Cust.balance + data.dbalance;
          alert("Successfully Deposit :" + data.dbalance);
          this.transaction.push(transaction);
          break;
  }
}
    }
  }
  withdrawDetails(data:any,transaction:Transaction){
    for (let i = 0; i < this.customer.length; i++) {
      let Cust = this.customer[i];
      if (Cust.accountNo == data.waccountNo) {
        if (Cust.pin == data.wpin) {
          Cust.balance = Cust.balance - data.wbalance;
          this.transaction.push(transaction);
          alert("Successfully Withdraw :" + data.wbalance);
          break;
  }
}
    }
  }
  fundTransfer(data: any, transaction: Transaction, trans1: Transaction) {
    for (let i = 0; i < this.customer.length; i++) {
      let Cust = this.customer[i];
      if (Cust.accountNo == data.sourceaccountNo) {
        if (Cust.pin == data.sourcepin) {
          if (Cust.balance > data.transferbalance) {
            for (let i = 0; i < this.customer.length; i++) {
              let Customr = this.customer[i];
              if (Customr.accountNo == data.destaccountNo) {
                Cust.balance = Cust.balance - data.transferbalance;
                Customr.balance = Customr.balance + data.transferbalance;
                this.transaction.push(transaction);
                console.log(transaction);
                console.log(trans1);
                this.transaction.push(trans1);
                alert("Successfully Transfer :" + data.transferbalance);
                break;
              }
            }
          }
        }
      }
    }
  }
  printTransaction(data: any): Transaction[] {
    let printTransactions: Transaction[] = [];
    for (let i = 0; i < this.customer.length; i++) {
      let customer = this.customer[i];
      if (customer.accountNo == data.transaccountNo) {
        if (customer.pin == data.transpin) {
          for (let i = 0; i < this.transaction.length; i++) {
            let trans = this.transaction[i];
            if (trans.accountNo == data.transaccountNo) {
              printTransactions.push(trans);
            }
          }
          return printTransactions;
        }
      }
    }
  }
}
