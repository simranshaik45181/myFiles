package com;

import java.sql.Date;

public class Employee {
	Date date;
	/*SqlDateEditor dateeditor;
	public Employee(SqlDateEditor dateeditor) {
		this.dateeditor=dateeditor;
	}

	public SqlDateEditor getDateeditor() {
		return dateeditor;
	}

	public void setDateeditor(SqlDateEditor dateeditor) {
		this.dateeditor = dateeditor;
	}
*/
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}



}
 