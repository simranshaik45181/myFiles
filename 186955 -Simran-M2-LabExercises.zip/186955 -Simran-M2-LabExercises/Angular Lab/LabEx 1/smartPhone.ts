import{Mobile} from './mobile';

export class Smartphone extends Mobile{
    mobType:string;
    constructor(mobsp)
    {
        super(101,"Redmi",524632);
        this.mobType=mobsp;
    }
    printMobileDetails()
    {
        super.printMobileDetails();
        console.log("Mobile Type of basic phone: "+this.mobType);
    }
}