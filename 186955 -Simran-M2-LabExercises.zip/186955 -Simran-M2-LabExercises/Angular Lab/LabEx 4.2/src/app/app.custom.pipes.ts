import { Pipe, PipeTransform } from "@angular/core";
import { Book } from "./Book";


@Pipe({
    name: "customPipe"
})
export class CustomPipes implements PipeTransform{
    
    transform(value: Book[], ...args: any[]) {
        
        if(args[1] == 1)
        {
            let book:Book[] = [];
            if(!args[0])
            return value;
            for(let data of value){
                if((data.id).toString().includes(args[0]))
                {
                    book.push(data);   
                }
            }
            return book;
        }

        if(args[1] == 2)
        {
            let book:Book[] = [];
            if(args[0] == 0)
            return value;
            for(let data of value){
                if(data.title.toLowerCase().includes((args[0] as string).toLowerCase()) )
                {
                    book.push(data);   
                }
            }
            return book;
        }

        if(args[1] == 4)
        {
            let book:Book[] = [];
            if(args[0] == 0)
            return value;
            for(let data of value){
                if(data.author.toLowerCase().includes((args[0] as string).toLowerCase()))
                {
                    book.push(data);   
                }
            }
            return book;
        }

        if(args[1] == 3)
        {
            let book:Book[] = [];
            if(args[0] == 0)
            return value;
            for(let data of value){
                if((data.year).toString().includes(args[0]))
                {
                    book.push(data);   
                }
            }
            return book;
        }

        if(args[1] == 0){
            return value;
        }

    }

}

