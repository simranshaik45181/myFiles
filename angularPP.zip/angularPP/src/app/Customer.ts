export class Customer{
    accountNo:number;
    name:String;
    mobileNo:number;
    adhaarNo:number;
    balance:number;
    pin:number
    constructor(accountNo:number,name:String,mobileNo:number,adhaarNo:number,balance:number,pin:number){
        this.accountNo=accountNo;
        this.name=name;
        this.mobileNo=mobileNo;
        this.adhaarNo=adhaarNo;
        this.balance=balance;
        this.pin=pin;

    }
}