import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Transaction } from '../Transaction';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  serviceService: ServiceService;
  transaction: Transaction;

  constructor(  serviceService: ServiceService) {
    this.serviceService=serviceService;
   }

   withdrawDetails(data:any){
    let transId = Math.floor(Math.random()*100) + 10;
     this.transaction=new Transaction(transId,"Withdraw",data.wbalance,data.waccountNo);
     this.serviceService.withdrawDetails(data, this.transaction);
   }

  ngOnInit() {
  }

}
