import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { ShowDetailsComponent } from './show-details/show-details.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionsComponent } from './print-transactions/print-transactions.component';
const routes: Routes = [
  {path:"app-createaccount",component:CreateaccountComponent},
  { path:"app-show-details", component: ShowDetailsComponent },
  { path:"app-deposit", component: DepositComponent },
  { path:"app-withdraw", component: WithdrawComponent },
  { path:"app-fund-transfer", component: FundTransferComponent },
  { path:"app-print-transaction", component: PrintTransactionsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
