import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Customer } from '../Customer';

@Component({
  selector: 'app-show-details',
  templateUrl: './show-details.component.html',
  styleUrls: ['./show-details.component.css']
})
export class ShowDetailsComponent implements OnInit {
serviceService:ServiceService;
getCustomerDetails:Customer;
name:String;
balance:number;
shown: boolean = true;
  constructor(serviceService:ServiceService) {
    this.serviceService=serviceService;
   }
showDetails(data:any){
  this.getCustomerDetails=this.serviceService.showDetails(data);
  this.name=this.getCustomerDetails.name;
  this.balance=this.getCustomerDetails.balance;
}
show(){
  this.shown = !this.shown;
}
  ngOnInit() {
  }

}
