export class Transaction{
    transId : number;
    transType : String;
    transBalance : number;
    accountNo : number;
   
    
    
    constructor(   transId : number,transType : String, transBalance : number,  accountNo : number){
        this.transId = transId; 
        this.transType = transType;
        this.transBalance = transBalance;
        this.accountNo = accountNo;
        
        
        
    } 
}