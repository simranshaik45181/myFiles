package com.cg.plp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlpApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlpApplication.class, args);
	}

}
