package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.ui.Client;


public class ProductDAO implements IProductDAO
{
	Client client=new Client();
 
	
	//map for ProductName as key and Category as value
	
		private static Map<String,String> productDetails;	
		static {
			productDetails= new HashMap<>();

	        productDetails.put("lux","soap");

	        productDetails.put("colgate","paste");

	        productDetails.put("pears","soap");

	        productDetails.put("sony","electronics");

	        productDetails.put("samsung","electronics");

	        productDetails.put("facepack", "cosmatics");

	        productDetails.put("facecream", "cosmatics");
	        


	}
		
		//map for Product name as key  and price as value value
		
		private static Map<String,Integer> salesDetails;
		static { 
			salesDetails= new HashMap<>();

	       salesDetails.put("lux", 100);

	       salesDetails.put("colgate", 50);

	       salesDetails.put("pears", 70);

	       salesDetails.put("sony", 10000);

	       salesDetails.put("samsung", 23000);

	       salesDetails.put("facepack", 100);

	       salesDetails.put("facecream", 60);  

		}
		//Getter and Setter
		
		public static Map<String, Integer> getSalesDetails() {
			return salesDetails;
		}

		public static void setSalesDetails(Map<String, Integer> salesDetails) {
			ProductDAO.salesDetails = salesDetails;
		}

		public static void setProductDetails(Map<String, String> productDetails) {
			  

			ProductDAO.productDetails = productDetails;
		}

		@Override
		public int updateProducts(String Category, int hike) throws ProductException {
			salesDetails.put(client.getCategory(), client.getHike());
			return 0;
		}

		@Override
		public Map<String, Integer> getProductDetails() {
			// TODO Auto-generated method stub
			return null;
		}
		
		//implement methods in the interface
}


