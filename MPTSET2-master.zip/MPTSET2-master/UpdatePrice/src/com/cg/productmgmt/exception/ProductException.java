package com.cg.productmgmt.exception;

@SuppressWarnings("serial")
public class ProductException extends Exception{
	public ProductException() {
		System.out.println("Category not found");
	}
	
}
