package com.cg.productmgmt.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;


public class Client 
{	
	
	private static String Category;//variable
	private static int hike;//variable
	
	



//	@Override
//	public String toString() {
//		return "Client [getCategory()=" + getCategory() + ", getHike()=" + getHike() + "]";
//	}



	public String getCategory() {
		return Category;
	}



	public void setCategory(String Category) {
		this.Category = Category;
	}



	public int getHike() {
		return hike;
	}



	public void setHike(int hike) {
		this.hike = hike;
	}



	/**
        Refer the sample input and output for the presentation layer messages
        Do not use tab or extra newline, which will lead to presentation error.
        Do not provide any additional messages, which is not asked for
    */
    public static void main(String [] args)  throws ProductException {
        Scanner sc=new Scanner(System.in);
        ProductService srvc=new ProductService();
//        EmployeeService empService = new EmployeeService();//service class object
//    	EmployeeDao ed = new EmployeeDao();
    	
    	
    	
    	
    	
    	int c;
    	do {
    		System.out.println("1)Update Product Price\n2)Exit");
    		c=sc.nextInt();
    		switch(c) {
    		case 1:
    			System.out.println("Enter the Product Category:");
    			Category=sc.next();
//    			Map<String, Integer> maps;
//    			try {
//    				maps=srvc.getProductDetails();
//    				if(Category==false) {
//    					
//    				}
//    			}
    			
    			System.out.println("Enter hike Rate:\n");
    			hike=sc.nextInt();
    			boolean res=srvc.isHikeValid(hike);
    			while(!res) {
    				if(res==false) {
    					System.out.println("Hike rate should be greater than zero");
    					System.out.println("Enter hike Rate:");
    				}
    			hike=sc.nextInt();
    			res=srvc.isHikeValid(hike);
    			}
    			srvc.updateProducts(Category, hike);
    			System.out.println("Product Name  Price \n");
    			for (HashMap.Entry<String, Integer> entry : srvc.getProductDetails().entrySet()) {
					
					System.out.println(entry.getKey() + " " + entry.getValue()+"\n");
					
				}
    			break;
    			
    			
    		case 2:
    			System.out.println("END");
    			return;
    			
    		}
    		
        }while(c!=2);
 sc.close();
    }
}

//
//
//
//
//
//[1) Update Product Price
//2) Exit
//Enter the Product Category :
//Enter hike Rate :
//Product Name Price
//tresemme 220
//realme 15000
//dove 187
//facialPowder 160
//lakmeLipstick 260
//fogg 250
//chairs 1600
//tulip 350
//mi 18000
//iphone 60000
//1) Update Product Price
//2) Exit
//Enter the Product Category :
//Enter hike Rate :
//Product Name Price
//tresemme 220
//realme 15000
//dove 187
//facialPowder 168
//lakmeLipstick 273
//fogg 250
//chairs 1600
//tulip 350
//mi 18000
//iphone 60000
//1) Update Product Price
//2) Exit
//
//
//
//
//[1)Update Product Price
//2)Exit
//Enter the Product Category:
//Enter hike Rate:
//Product Name Price
//tresemme 200
//shampoo 10
//realme 15000
//dove 170
//facialPowder 160
//lakmeLipstick 260
//fogg 250
//chairs 1600
//tulip 350
//mi 18000
//iphone 60000
//1)Update Product Price
//2)Exit
//Enter the Product Category:
//Enter hike Rate:
//Product Name  Price
//tresemme 200
//shampoo 10
//realme 15000
//dove 170
//facialPowder 160
//lakmeLipstick 260
//fogg 250
//chairs 1600
//tulip 350
//mi 18000
//iphone 60000
//cosmetics 5
//1)Update Product Price
//2)Exit
//END]")