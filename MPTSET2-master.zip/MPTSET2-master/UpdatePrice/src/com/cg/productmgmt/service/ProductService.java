package com.cg.productmgmt.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.ui.Client;


public class ProductService implements IProductService
{
	Client client=new Client();
	ProductDAO dao=new ProductDAO();
    public int updateProducts(String Category,int hike) throws ProductException {
    	try {
    		
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    	dao.updateProducts(Category, hike);
    	return 0;
    	
    }

    public Map<String,Integer> getProductDetails(){
    	return ProductDAO.getSalesDetails();
    }
    
    public boolean isHikeValid(int hike) {
    	if(hike<0)
    		return false;
    	else 
    		return true;
    }
    public boolean isCategoryValid(String category) throws ProductException {
    	if(category=="soap"||category=="paste"||category=="electronics"||category=="cosmatics") {
    		return true;
    	}else
    		return false;
    }
 
}



//EmployeeDao empDao = new EmployeeDao();
//
//public void addDetails(EmployeeBean empBean) {
//	empDao.addEmp(empBean);
//}
//
//public HashMap<Integer, EmployeeBean> searchEmp() {
//	return empDao.hm();
//}
//public void remDetails(int id) {
//	empDao.remEmp(id);
//}
//}